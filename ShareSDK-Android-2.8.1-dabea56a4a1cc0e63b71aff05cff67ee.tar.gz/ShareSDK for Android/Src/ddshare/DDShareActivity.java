package cn.sharesdk.demo.ddshare;

import cn.sharesdk.dingding.utils.DingdingHandlerActivity;


public class DDShareActivity extends DingdingHandlerActivity {

}
